package com.company;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        System.out.println(Arrays.toString(createArrayOfIntegers(10)));

        // Output: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }

    public static int[] createArrayOfIntegers(int n) {
        int[] array = new int[n];
        array[0] = 1;
        int a = 0;
        int b = 1;
        for (int i = 1; i < n; i++) {
            if (array[i-1] > 0){
                array[i] = (a - 2);
                a = array[i];
            }
            if (array[i-1] < 0){
                array[i] = (b + 2);
                b = array[i];

            }

        }

        return array;
    }

        // write your code here
    }

