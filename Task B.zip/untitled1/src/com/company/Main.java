package com.company;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
        System.out.println(Arrays.toString(createArrayOfIntegers(10)));

        // Output: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }

    public static int[] createArrayOfIntegers(int n) {
        int[] array = new int[n];
        array[0] = 1;

        for (int i = 1; i < n; i++) {
            array[i] = array[i-1] + 2;



        }

        return array;
    }

        // write your code here
    }

